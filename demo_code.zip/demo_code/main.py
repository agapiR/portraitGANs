import os
import face_recognition

from skimage.io import imshow
from skimage.io import imsave
from skimage.transform import resize

import matplotlib.pyplot as plt


# detect faces in the image
def detect_faces(image, margin_factor, idx):

    # find the locations of the face
    face_locations = face_recognition.face_locations(image)

    print("I found {} face(s) in this photograph.".format(len(face_locations)))

    for sub_idx, face_location in enumerate(face_locations):
        # Print the location of each face in this image
        top, right, bottom, left = face_location
        print("A face is located at pixel location Top: {}, Left: {}, Bottom: {}, Right: {}".format(top, left, bottom,
                                                                                                    right))
        # You can access the actual face itself like this:
        face_image = image[top - margin_factor:bottom + margin_factor, left - margin_factor:right + margin_factor]

        # resize the image
        face_image = resize(face_image, (224, 224))

        # show the detection result
        imshow(face_image)
        plt.show()

        # save the image
        img_name = './testA/' + str(idx) + '_' + str(sub_idx) + '.png'
        imsave(img_name, face_image)


if __name__ == '__main__':

    # directory stores the raw images
    root_dir = './demo_img'
    margin_factor = 100

    # get the images under the folder
    img_files = os.listdir(root_dir)

    # crop the image and resize
    img_num = len(img_files)

    # check the result directory
    if os.path.exists('./testA'):
        os.system('rm -r %s' % './testA')
    else:
        os.mkdir('./testA')

    # pre-process the images
    for i in range(img_num):
        # load i-th image
        img = face_recognition.load_image_file((root_dir+'/'+img_files[i]))

        # detect faces on the image
        detect_faces(img, margin_factor, i)




