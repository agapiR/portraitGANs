git clone https://github.com/davisking/dlib.git

sudo apt install cmake

cd dlib
mkdir build; cd build; cmake ..; cmake --build .

cd ..
python3 setup.py install

pip3 install --user face_recognition
